package com.client.lambdafitbit;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author survi
 */
public class ClientToFindTop3 {

	static BlockingQueue<Double> bq = new LinkedBlockingQueue<>();
	static File file1 = new File("./sql_latency.txt");
	static ReqSent rq = new ReqSent(bq);
	

	public static void main(String args[]) throws FileNotFoundException, IOException {
		int interval = new Integer(args[0]);
		ScheduledExecutorService service = Executors.newSingleThreadScheduledExecutor();
		service.scheduleAtFixedRate(new MyThreadClass(), 0, interval, TimeUnit.SECONDS);
		rq.run();
	}

	public static String callGetCurrent() {
		try {
			String steps = LambdaInvokeSteps.getCurrent();
			return steps;
		} catch (Exception e) {
			e.printStackTrace();
			return "";
		}

	}

	static class MyThreadClass implements Runnable {
		@Override
		public void run() {
			long start = System.currentTimeMillis();
			String result = callGetCurrent();
			long end = System.currentTimeMillis();
			double wall = (double)(end - start) / 1000f;
			bq.offer(wall);
			rq.run();
			DateFormat simple = new SimpleDateFormat("dd MMM yyyy HH:mm:ss:SSS Z");
			Date now = new Date(end);
			System.out.println("Reporting top 3 users per day at" + simple.format(now));
			System.out.println(result);
		}
	}

	static class ReqSent implements Runnable {
		BlockingQueue<Double> q;
		BufferedWriter writer;
		public ReqSent(BlockingQueue queue) {
			this.q = queue;
			try {
				writer = new BufferedWriter(new FileWriter(file1,true));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		public void run() {
			
			try {
				while (!q.isEmpty()) {
					String content =  String.format("%.12f",(double) q.take()) + "\n";
					writer.write(content);
					writer.flush();
				}
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (InterruptedException ex) {
				Logger.getLogger(ClientToFindTop3.class.getName()).log(Level.SEVERE, null, ex);
			}
//			finally {
//				try {
//					writer.close();
//				} catch (IOException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//			}
		}
	}

}
