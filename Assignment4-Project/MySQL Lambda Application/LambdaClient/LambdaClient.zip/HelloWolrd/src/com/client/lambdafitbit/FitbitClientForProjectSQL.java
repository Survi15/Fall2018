package com.client.lambdafitbit;


import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadLocalRandom;

/**
 *
 * @author survi
 */
public class FitbitClientForProjectSQL {

	static int requestCount = 0;
	static int responseCount = 0;
	static int counter = 0;
	static HashMap<Long, ArrayList<Long>> map;
	static TreeMap<Long, ArrayList<Long>> treeMap;
	static TreeMap<Long, Integer> requestsPerSecondMap;
	static BlockingQueue<Integer> bq = new LinkedBlockingQueue<>();
	static BlockingQueue<Integer> bq1 = new LinkedBlockingQueue<>();
	static BlockingQueue<Integer> bq2 = new LinkedBlockingQueue<>();
	public static void main(String args[]) throws FileNotFoundException, IOException {
		int threadCount = new Integer(args[0]);
		int dayNum = new Integer(args[1]);
		int userSize = new Integer(args[2]);
		int iterationCount = new Integer(args[3]);
		double[] phaseFactors = new double[] { 0.1, 0.5, 1.0, 0.25 };
		String[] phaseTypes = new String[] { "Warmup", "Load", "Peak", "Cooldown" };
		int[] phaseLength = new int[] { 3, 5, 11, 5 };
		int[][] phaseMaxMin = new int[][] { { 0, 2 }, { 3, 7 }, { 8, 18 }, { 19, 23 } };
		map = new HashMap<>();
		System.out.println("Client: Thread Count: " + threadCount + ", Iteration Count: " + iterationCount);
		long clientStart = System.currentTimeMillis();
		System.out.println("Client starting time: " + clientStart + " milliseconds");
		for (int i = 0; i < phaseFactors.length; i++) {
			createPhase(threadCount, phaseTypes[i], phaseFactors[i], phaseLength[i], phaseMaxMin[i], iterationCount,
					dayNum, userSize);
		}
		long endTime = System.currentTimeMillis();
		System.out.println("Client end time: " + endTime + " milliseconds");
		System.out.println("=========================================");
		double wall = (endTime - clientStart) / 1000f;
		System.out.printf("Total wall time: %.3f seconds\n", wall);
	}

	public static float getLatencyFromList(ArrayList<Long> list) {
		float result = 0f;
		if (list.size() == 1) {
			result = list.get(0) / 1000f;
			return result;
		}
		int sum = 0;
		for (long var : list) {
			sum += var;
		}
		result = (sum / list.size()) / 1000f;
		return result;
	}

	public static void createPhase(int threadCount, String phaseType, double phaseFactor, int phaseLength,
			int[] phaseMaxMin, int iterationCount, int day, int userSize) {
		int totalThreads = (int) (threadCount * phaseFactor);
		CountDownLatch latch = new CountDownLatch(totalThreads);
		iterationCount *= phaseLength;
		ExecutorService executor = Executors.newFixedThreadPool(totalThreads);
		long startTime = System.currentTimeMillis();
		for (int i = 0; i < totalThreads; i++) {
			executor.submit(new MyThreadClass(latch, phaseMaxMin, iterationCount, day, userSize));
		}
		System.out.println(phaseType + " phase:All threads running...");
		try {
			latch.await();
		} catch (InterruptedException ex) {
			Logger.getLogger(FitbitClientForProjectSQL.class.getName()).log(Level.SEVERE, null, ex);
		}
		executor.shutdown();
		long endTime = System.currentTimeMillis();
		System.out.printf(phaseType + " phase complete time: %.3f seconds\n", ((endTime - startTime) / 1000f));

	}

	static class MyThreadClass implements Runnable {

		private final CountDownLatch stopLatch;
		private final int iterationCount;
		private final int day;
		private final int userSize;
		private final int[] maxMin;
		private final int[] user = new int[3];
		private final int[] time = new int[3];
		private final int[] step = new int[3];

		public MyThreadClass(CountDownLatch stopLatch, int[] maxMin, int iterationCount, int day, int userSize) {
			super();
			this.stopLatch = stopLatch;
			this.iterationCount = iterationCount;
			this.day = day;
			this.userSize = userSize;
			this.maxMin = maxMin;
		}

		@Override
		public void run() {
			for (int i = 0; i < iterationCount; i++) {
				for (int j = 0; j < 3; j++) {
					user[j] = ThreadLocalRandom.current().nextInt(userSize) + 1;
					time[j] = getRandomTimeInRange();
					step[j] = ThreadLocalRandom.current().nextInt(5000) + 1;
					int day = ThreadLocalRandom.current().nextInt(30) + 1;
					int res = LambdaInvokeSteps.postSteps(user[j], day, time[j], step[j]);
				}
			}
			stopLatch.countDown();
		}

		private int getRandomTimeInRange() {
			return ThreadLocalRandom.current().nextInt((maxMin[1] - maxMin[0]) + 1) + maxMin[0];
		}

		private boolean checkPost(int user, int time, int step) {
			bq.offer(1);
			int res = LambdaInvokeSteps.postSteps(user, 1, time, step);
			bq1.offer(1);
			return  res!= -1;
		}
	}

	

	

	

	

	

}
