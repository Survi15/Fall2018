package com.amazonaws.lambda.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;

public class GetRangeCount implements RequestHandler<Map<String, String>, Map<String, String>> {
	static final String DB_URL = "jdbc:mysql://mydbinstance.cwrcdvaet30p.us-west-2.rds.amazonaws.com:3306";
	static final String USER = "survi15";
	static final String PASS = "survi123";

	@Override
	public Map<String, String> handleRequest(Map<String, String> input, Context context) {
		String userID = (String) input.get("userID");
		int day = Integer.parseInt(input.get("day"));
		int numDays = Integer.parseInt(input.get("numDays"));
		int[] result = new int[day + numDays - 1];
		Arrays.fill(result, 0);
		int index = 0, endDay = day + numDays - 1;
		Connection con = null;
		try {
			con = DriverManager.getConnection(DB_URL, USER, PASS);
			if (con != null) {
				PreparedStatement stmt = con.prepareStatement(
						"select sum(UserSteps.Fitbit.StepCount) from " + "UserSteps.Fitbit where userID=" + userID
								+ " and Day>=" + day + " and Day<=" + endDay + " group by day order by day");
				ResultSet resultset = stmt.executeQuery();
				while (resultset.next()) {
					result[index++] = resultset.getInt(1);
				}
				con.close();
				stmt.close();
				resultset.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		Map<String, String> responseMap = new HashMap<>();
		responseMap.put("response", Arrays.toString(result));
		return responseMap;
	}
}
