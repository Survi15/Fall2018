package com.amazonaws.lambda.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;

public class GetCount implements RequestHandler<Map<String, String>, Map<String, String>> {

	static final String DB_URL = "jdbc:mysql://mydbinstance.cwrcdvaet30p.us-west-2.rds.amazonaws.com:3306";
	static final String USER = "survi15";
	static final String PASS = "survi123";

	@Override
	public Map<String, String> handleRequest(Map<String, String> input, Context context) {
		int result = -1;
		String userID = (String) input.get("userID");
		String day = (String) input.get("day");
		Connection con = null;
		try {
			con = DriverManager.getConnection(DB_URL, USER, PASS);
			if (con != null) {
				PreparedStatement stmt = con
						.prepareStatement("select sum(UserSteps.Fitbit.StepCount) from UserSteps.Fitbit use index(idx_Fitbit_UserID_Day) where "
								+ "userID=" + userID + " and Day=" + day);
				ResultSet resultset = stmt.executeQuery();
				resultset.next();
				result = resultset.getInt(1);
				con.close();
				stmt.close();
				resultset.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		Map<String, String> responseMap = new HashMap<>();
		responseMap.put("response", String.valueOf(result));
		return responseMap;
	}
}
