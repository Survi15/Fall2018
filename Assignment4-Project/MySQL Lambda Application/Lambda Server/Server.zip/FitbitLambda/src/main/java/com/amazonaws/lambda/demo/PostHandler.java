package com.amazonaws.lambda.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;

public class PostHandler implements RequestHandler<Map<String, String>, Map<String, String>> {

	static final String DB_URL = "jdbc:mysql://users-db-instance.cencewpomadk.us-east-1.rds.amazonaws.com:3306/TopUsers?autoReconnect=true&useSSL=false";	
	static final String USER = "survi15";
	static final String PASS = "survi123";

	@Override
	public Map<String, String> handleRequest(Map<String, String> input, Context context) {

		String userID = (String) input.get("userID");
		String day = (String) input.get("day");
		String timeInterval = (String) input.get("hour");
		String stepCount = (String) input.get("stepCount");
		int responsecode = -1;
		Connection con = null;
		try {
			con = DriverManager.getConnection(DB_URL, USER, PASS);
			
			if (con != null) {
				Statement statement = con.createStatement();
				String query = "Insert into TopUsers.MaxSteps value("
						+userID+","+day+","+timeInterval+","+stepCount+")"
						+" on duplicate key update Steps = Steps+"
						+ stepCount + ";";
				responsecode = statement.executeUpdate(query);
				statement.close();
				con.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		Map<String, String> responseMap = new HashMap<>();
		responseMap.put("response", String.valueOf(responsecode));
		return responseMap;

	}

}
