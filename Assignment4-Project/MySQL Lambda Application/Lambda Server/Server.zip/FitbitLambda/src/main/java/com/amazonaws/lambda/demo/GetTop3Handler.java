package com.amazonaws.lambda.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;

public class GetTop3Handler implements RequestHandler<Map<String, String>, Map<String, String>> {

	static final String DB_URL = "jdbc:mysql://users-db-instance.cencewpomadk.us-east-1.rds.amazonaws.com:3306/TopUsers?autoReconnect=true&useSSL=false";	
	static final String USER = "survi15";
	static final String PASS = "survi123";

	@Override
	public Map<String, String> handleRequest(Map<String, String> input, Context context) {

		String result="";
		int responsecode = -1;
		Connection con = null;
		try {
			con = DriverManager.getConnection(DB_URL, USER, PASS);	
			if (con != null) {
				PreparedStatement stmt = con.prepareStatement("select Day, UserID, Steps " + 
						"from TopUsers.MaxSteps as main " + 
						"where ( " + 
						"select count(*) from TopUsers.MaxSteps as f" + 
						"   where f.Day = main.Day and f.Steps >= main.Steps" + 
						") <= 3 order by main.Day asc, main.Steps desc;");
				ResultSet resultset = stmt.executeQuery();
				while(resultset.next()) {
					result = result+"Day: "+resultset.getInt(1)+" UserID: "+resultset.getInt(2)+
							" TotalSteps: "+resultset.getInt(3)+"\n";
				}
				resultset.next();
				con.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		Map<String, String> responseMap = new HashMap<>();
		responseMap.put("response", result);
		return responseMap;

	}

}
