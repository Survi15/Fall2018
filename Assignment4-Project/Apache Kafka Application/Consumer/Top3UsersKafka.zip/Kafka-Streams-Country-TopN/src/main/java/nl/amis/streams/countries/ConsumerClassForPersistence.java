package nl.amis.streams.countries;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Scanner;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import nl.amis.streams.countries.AddStepsForUser.UserTotal;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.errors.WakeupException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Properties;
import java.util.Scanner;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.PropertiesCredentials;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.PrimaryKey;
import com.amazonaws.services.dynamodbv2.document.PutItemOutcome;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.GetItemRequest;
import com.amazonaws.services.dynamodbv2.model.GetItemResult;
import com.amazonaws.services.dynamodbv2.document.Table;

public class ConsumerClassForPersistence {

	static public class UserTotal {
		public String userid;
		public String day;
		public int totalSteps;

		public UserTotal() {
			this.userid = "";
			this.day = "";
			this.totalSteps = 0;
		}
		
		public String userToString() {
			return "userid: "+userid+" totalSteps: "+totalSteps;
		}
	}

	static public class UserTop3 {

		public UserTotal[] nrs = new UserTotal[4];

		public UserTop3() {
		}
	}
	public static AmazonDynamoDB client = null; 
	
	private static Scanner in;
	public static Table table;
	

	public static void main(String[] argv) {
		if (argv.length != 2) {
			System.out.println("Usage: <topicName> <groupId>\n");
			System.exit(-1);
		}
		in = new Scanner(System.in);
		String topicName = argv[0].toString();
		String groupId = argv[1].toString();
		AWSCredentials credentials;
		try {
			credentials = new PropertiesCredentials(
					ConsumerClassForPersistence.class
							.getResourceAsStream("AwsCredentials.properties"));
			client = new AmazonDynamoDBClient(credentials);
			client.setRegion(Region.getRegion(Regions.US_EAST_1));
			DynamoDB dbclient=new DynamoDB(client);
			table = dbclient.getTable("TopUsers");
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
		ConsumerThread consumerRunnable = new ConsumerThread(topicName, groupId);
		consumerRunnable.start();
		String line = "";
		while (!line.equals("exit")) {
			line = in.next();
		}
		consumerRunnable.getKafkaConsumer().wakeup();
		System.out.println("Stopping consumer .....");
		try {
			consumerRunnable.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private static class ConsumerThread extends Thread {
		private String topicName;
		private String groupId;
		private KafkaConsumer<String, JsonNode> kafkaConsumer;

		public ConsumerThread(String topicName, String groupId) {
			this.topicName = topicName;
			this.groupId = groupId;
		}

		public void run() {
			Properties configProperties = new Properties();
			configProperties.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
			configProperties.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,
					"org.apache.kafka.common.serialization.ByteArrayDeserializer");
			configProperties.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,
					"org.apache.kafka.connect.json.JsonDeserializer");
			configProperties.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
			configProperties.put(ConsumerConfig.CLIENT_ID_CONFIG, "simple");
			configProperties.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, "30000");
			configProperties.put(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG, "1000");
			configProperties.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "true");
			// Figure out where to start processing messages from
			kafkaConsumer = new KafkaConsumer<String, JsonNode>(configProperties);
			kafkaConsumer.subscribe(Arrays.asList(topicName));
			System.out.println("subscribed to topic " + topicName);
			ObjectMapper mapper = new ObjectMapper();

			// Start processing messages
			try {
				while (true) {
					ConsumerRecords<String, JsonNode> records = kafkaConsumer.poll(100);
					for (ConsumerRecord<String, JsonNode> record : records) {
						JsonNode jsonNode = record.value();
						UserTop3 usertop3 = mapper.treeToValue(jsonNode, UserTop3.class);
						if (usertop3 != null) {
							List<String> ls = new ArrayList<>();
							String pKey = "";
							for (int i = 0; i < usertop3.nrs.length; i++) {
								pKey = usertop3.nrs[0].day;
								if (usertop3.nrs[i] != null) {
									ls.add(usertop3.nrs[i].userToString());
								}
							}
							
							try {
								Map<String,List<String>> topusers = new HashMap<String,List<String>>();
								topusers.put("list_of_users", ls);
								Item item = new Item()
										.withPrimaryKey("day",pKey)
										.withMap("top3", topusers);
								table.putItem(item);
								
							} catch (Exception e) {
								System.err.println("Unable to store data: ");
								System.err.println(e.getMessage());
							}
						}
					}
				}
			} catch (WakeupException ex) {
				System.out.println("Exception caught " + ex.getMessage());
			} catch (JsonProcessingException e) {
				e.printStackTrace();
			} finally {
				kafkaConsumer.close();
				System.out.println("After closing KafkaConsumer");
			}
		}

		public KafkaConsumer<String, JsonNode> getKafkaConsumer() {
			return this.kafkaConsumer;
		}
	}

}
