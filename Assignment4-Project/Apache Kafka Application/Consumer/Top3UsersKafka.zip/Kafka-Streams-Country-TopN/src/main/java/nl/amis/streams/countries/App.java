package nl.amis.streams.countries;

import nl.amis.streams.JsonPOJOSerializer;
import nl.amis.streams.countries.AddStepsForUser.UserTotal;
import nl.amis.streams.JsonPOJODeserializer;

// generic Java imports
import java.util.Properties;
import java.util.HashMap;
import java.util.Map;
import java.util.Arrays;
// Kafka imports
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.common.serialization.Serializer;
import org.apache.kafka.common.serialization.Deserializer;
// Kafka Streams related imports
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.KTable;
import org.apache.kafka.streams.kstream.KStreamBuilder;
import org.apache.kafka.streams.processor.WallclockTimestampExtractor;
import org.apache.kafka.streams.kstream.TimeWindows;

public class App {


	static public class UserTop3 {

		public UserTotal[] nrs = new UserTotal[4];

		public UserTop3() {
		}
	}

	private static final String APP_ID = "fitbit-users-top3-kafka-streaming-analysis-app";

	public static void main(String[] args) {
		System.out.println("Fitbit Users Top 3");

		// Create an instance of StreamsConfig from the Properties instance
		StreamsConfig config = new StreamsConfig(getProperties());
		final Serde<String> stringSerde = Serdes.String();

		// define countryMessageSerde
		Map<String, Object> serdeProps = new HashMap<String, Object>();
		final Serializer<UserTotal> userMessageSerializer = new JsonPOJOSerializer<>();
		serdeProps.put("JsonPOJOClass", UserTotal.class);
		userMessageSerializer.configure(serdeProps, false);

		final Deserializer<UserTotal> userMessageDeserializer = new JsonPOJODeserializer<>();
		serdeProps.put("JsonPOJOClass", UserTotal.class);
		userMessageDeserializer.configure(serdeProps, false);
		final Serde<UserTotal> userMessageSerde = Serdes.serdeFrom(userMessageSerializer, userMessageDeserializer);

		// define userTop3Serde
		serdeProps = new HashMap<String, Object>();
		final Serializer<UserTop3> userTop3Serializer = new JsonPOJOSerializer<>();
		serdeProps.put("JsonPOJOClass", UserTop3.class);
		userTop3Serializer.configure(serdeProps, false);

		final Deserializer<UserTop3> userTop3Deserializer = new JsonPOJODeserializer<>();
		serdeProps.put("JsonPOJOClass", UserTop3.class);
		userTop3Deserializer.configure(serdeProps, false);
		final Serde<UserTop3> userTop3Serde = Serdes.serdeFrom(userTop3Serializer, userTop3Deserializer);

		// building Kafka Streams Model
		KStreamBuilder kStreamBuilder = new KStreamBuilder();
		// the source of the streaming analysis is the topic with user messages
		KStream<String, UserTotal> usersStream = kStreamBuilder.stream(stringSerde, userMessageSerde, "UserStepsPerDay");
		
// A hopping time window with a size of 5 minutes and an advance interval of 1 minute.
// The window's name -- the string parameter -- is used to e.g. name the backing state store.
		long windowSizeMs = 5 * 60 * 1000L;
		long advanceMs = 1 * 60 * 1000L;
		TimeWindows.of("hopping-window-example", windowSizeMs).advanceBy(advanceMs);

		// THIS IS THE CORE OF THE STREAMING ANALYTICS:
		// top 3 largest countries per continent, published to topic
		// Top3UsersWithMostStepsByDay
		KTable<String, UserTop3> top3PerDay = usersStream
				// the dimension for aggregation is day; assign the day as the key
				// for each message
				.selectKey((k, user) -> user.day)
				// for each key value perform an aggregation
				.aggregateByKey(
						// first initialize a new UserTop3 object, initially empty
						UserTop3::new, // for each user in the day, invoke the aggregator, passing in the
										// day, the user element and the UserTop3 object for the day
						(dayUserIdKey, userMsg, top3) -> {
							// add the new user as the last element in the nrs array
							top3.nrs[3] = userMsg;
							// sort the array by totalSteps, largest first
							Arrays.sort(
									top3.nrs, (a, b) -> {
                                // in the initial cycles, not all nrs element contain a UserMessage object  
                                if (a==null)  return 1;
                                if (b==null)  return -1;
                                // with two proper UserMessage objects, do the normal comparison
                                return Integer.compare(b.totalSteps, a.totalSteps);
                              });
							top3.nrs[3]=null;
	                        return (top3);
						}, stringSerde, userTop3Serde, "Top3UsersPerDay");
		// publish the Top3 messages to Kafka Topic Top3UsersWithMostStepsByDay
		top3PerDay.to(stringSerde, userTop3Serde, "Top3UsersWithMostStepsByDay");

		// prepare Top3 messages to be printed to the console
		top3PerDay.<String>mapValues((top3) -> {
			String rank = " 1. userid=" + top3.nrs[0].userid + " - steps=" + top3.nrs[0].totalSteps
					+ ((top3.nrs[1] != null) ? ", 2. userid=" + top3.nrs[1].userid + " - steps=" + top3.nrs[1].totalSteps
							: "")
					+ ((top3.nrs[2] != null) ? ", 3. userid=" + top3.nrs[2].userid + " - steps=" + top3.nrs[2].totalSteps
							: "");
			return "List for " + top3.nrs[0].day + rank;
		}).print(stringSerde, stringSerde);

		System.out.println("Starting Kafka Streams Users");
		KafkaStreams kafkaStreams = new KafkaStreams(kStreamBuilder, config);
		kafkaStreams.start();
		System.out.println("Now started UsersStreams");
	}

	private static Properties getProperties() {
		Properties settings = new Properties();
		// Set a few key parameters
		settings.put(StreamsConfig.APPLICATION_ID_CONFIG, APP_ID);
		// Kafka bootstrap server (broker to talk to); ubuntu is the host name for my VM
		// running Kafka, port 9092 is where the (single) broker listens
		settings.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
		// Apache ZooKeeper instance keeping watch over the Kafka cluster; ubuntu is the
		// host name for my VM running Kafka, port 2181 is where the ZooKeeper listens
		settings.put(StreamsConfig.ZOOKEEPER_CONNECT_CONFIG, "localhost:2181");
		// default serdes for serialzing and deserializing key and value from and to
		// streams in case no specific Serde is specified
		settings.put(StreamsConfig.KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName());
		settings.put(StreamsConfig.VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName());
		settings.put(StreamsConfig.STATE_DIR_CONFIG, "C:\\temp1");
		// to work around exception Exception in thread "StreamThread-1"
		// java.lang.IllegalArgumentException: Invalid timestamp -1
		// at
		// org.apache.kafka.clients.producer.ProducerRecord.<init>(ProducerRecord.java:60)
		// see: https://groups.google.com/forum/#!topic/confluent-platform/5oT0GRztPBo
		settings.put(StreamsConfig.TIMESTAMP_EXTRACTOR_CLASS_CONFIG, WallclockTimestampExtractor.class);
		return settings;
	}

}