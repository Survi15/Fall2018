package nl.amis.streams.countries;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.errors.WakeupException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat; 
import java.text.SimpleDateFormat; 
import java.util.Date;
import nl.amis.streams.countries.ConsumerClassForPersistence.UserTop3;


public class ReportGeneration {
	private static Scanner in;
	static BlockingQueue<Float> bq = new LinkedBlockingQueue<>();
	static ReqSent rq = new ReqSent(bq);
	static File file1 = new File("./output2.txt");
    public static void main(String[] argv)throws Exception{
        if (argv.length != 3) {
            System.out.println("Usage: <topicName> <groupId> <interval>\n");
            System.exit(-1);
        }
        in = new Scanner(System.in);
        String topicName = argv[0].toString();
        String groupId = argv[1].toString();
        Integer interval=Integer.parseInt(argv[2].toString());
        ConsumerThread consumerRunnable = new ConsumerThread(topicName,groupId,interval);
        consumerRunnable.start();
        String line = "";
        while (!line.equals("exit")) {
            line = in.next();
        }
        consumerRunnable.getKafkaConsumer().wakeup();
        rq.run();
        System.out.println("Stopping consumer .....");
        consumerRunnable.join();
    }
    
    private static class ConsumerThread extends Thread{
        private String topicName;
        private String groupId;
        private int interval;
        private KafkaConsumer<String,JsonNode> kafkaConsumer;

        public ConsumerThread(String topicName, String groupId,int interval){
            this.topicName = topicName;
            this.groupId = groupId;
            this.interval = interval*1000;
        }
        public void run() {
            Properties configProperties = new Properties();
            configProperties.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
            configProperties.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.ByteArrayDeserializer");
            configProperties.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, "org.apache.kafka.connect.json.JsonDeserializer");
            configProperties.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
            configProperties.put(ConsumerConfig.CLIENT_ID_CONFIG, "simple");
            configProperties.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, "30000");
            configProperties.put(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG,"1000");
            configProperties.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "true");
            //Figure out where to start processing messages from
            kafkaConsumer = new KafkaConsumer<String, JsonNode>(configProperties);
            kafkaConsumer.subscribe(Arrays.asList(topicName));
            System.out.println("subscribed to topic "+topicName);
            ObjectMapper mapper = new ObjectMapper();

            //Start processing messages
            try {
                while (true) {
                	long start = System.currentTimeMillis();
                    ConsumerRecords<String, JsonNode> records = kafkaConsumer.poll(interval);
                    long current = System.currentTimeMillis();
                    long wall = current-start;
                    bq.offer(wall/1000f);
                    rq.run();
                    DateFormat simple = new SimpleDateFormat("dd MMM yyyy HH:mm:ss:SSS Z"); 
                    Date result = new Date(current);
                    System.out.println("Reporting top 3 per day at"+simple.format(result));
                    for (ConsumerRecord<String, JsonNode> record : records) {
                        JsonNode jsonNode = record.value();
                        UserTop3 usertop3 = mapper.treeToValue(jsonNode, UserTop3.class);
                        List<String> ls = new ArrayList<>();
						String pKey = "";
						for (int i = 0; i < usertop3.nrs.length; i++) {
							pKey = usertop3.nrs[0].day;
							if (usertop3.nrs[i] != null) {
								ls.add(usertop3.nrs[i].userToString());
							}
						}
						System.out.println("Day:"+pKey+Arrays.toString(ls.toArray()));
                    }
                }
            }catch(WakeupException ex){
                System.out.println("Exception caught " + ex.getMessage());
            }catch (JsonProcessingException e) {
                e.printStackTrace();
            } finally{
                kafkaConsumer.close();
                System.out.println("After closing KafkaConsumer");
            }
        }
        public KafkaConsumer<String,JsonNode> getKafkaConsumer(){
            return this.kafkaConsumer;
        }
    }
    
    static class ReqSent implements Runnable{
    	BlockingQueue<Float> q;

		public ReqSent(BlockingQueue queue) {
			this.q = queue;
		}

		public void run() {
			try {
				while (!q.isEmpty()) {
					BufferedWriter writer;
					try {
						writer = new BufferedWriter(new FileWriter(file1,true));
						writer.write(String.format("%.12f",(double) q.take()) + "\n");
						writer.close();
					} catch (IOException e1) {
						e1.printStackTrace();
					}	
				}
			} catch (InterruptedException ex) {
				Logger.getLogger(ReqSent.class.getName()).log(Level.SEVERE, null, ex);
			}
		}
    	
    }
}
