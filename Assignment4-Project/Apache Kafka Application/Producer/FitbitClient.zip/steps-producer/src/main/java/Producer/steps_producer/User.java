package Producer.steps_producer;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.StringTokenizer;
public class User {
	private int userid;
	private int steps;
	private int day;
	private int hour;
	public User(){

    }
	public User(int userid, int steps, int day, int hour) {
		super();
		this.userid = userid;
		this.steps = steps;
		this.day = day;
		this.hour = hour;
	}
	public void parseString(String generatedStr){
        StringTokenizer st = new StringTokenizer(generatedStr,"/");
        userid = Integer.parseInt(st.nextToken());
        day = Integer.parseInt(st.nextToken());
        hour = Integer.parseInt(st.nextToken());
        steps = Integer.parseInt(st.nextToken());
    }
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public int getSteps() {
		return steps;
	}
	public void setSteps(int steps) {
		this.steps = steps;
	}
	public int getDay() {
		return day;
	}
	public void setDay(int day) {
		this.day = day;
	}
	public int getHour() {
		return hour;
	}
	public void setHour(int hour) {
		this.hour = hour;
	}
	@Override
	public String toString() {
		return "User[userid=" + userid +
				", day=" + day + 
				", hour=" + hour +
				", steps=" + steps + "]";
	}
	
//	public static void main(String args[])throws Exception {
//		ObjectMapper mapper = new ObjectMapper();
//		User some = new User();
//		some.setUserid(1);
//		some.setDay(1);
//		some.setHour(2);
//		some.setSteps(500);
//		System.out.println(mapper.writeValueAsString(some));
//		some.parseString("2/1/3/400");
//		System.out.println(mapper.writeValueAsString(some));
//		
//		
//	}
	
	
	
}
