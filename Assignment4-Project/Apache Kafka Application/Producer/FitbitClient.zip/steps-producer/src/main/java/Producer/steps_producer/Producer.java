package Producer.steps_producer;

import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.connect.json.JsonSerializer;
public class Producer {
	public static void send(String topicName, String record) throws Exception {

		
		// Configure the Producer
		Properties configProperties = new Properties();
		configProperties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
		configProperties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,
				"org.apache.kafka.connect.json.JsonSerializer");
		 configProperties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,
				 "org.apache.kafka.connect.json.JsonSerializer");
		

		// Specify buffer size in config
		configProperties.put("batch.size", 16384);

		// Reduce the no of requests less than 0
		configProperties.put("linger.ms", 1);

		// The buffer.memory controls the total amount of memory available to the
		// producer for buffering.
		configProperties.put("buffer.memory", 33554432);
		Thread.currentThread().setContextClassLoader(null);
		org.apache.kafka.clients.producer.Producer<String, JsonNode> producer = new KafkaProducer<String,JsonNode>(configProperties);

		ObjectMapper objectMapper = new ObjectMapper();

		User user = new User();
		user.parseString(record);
		JsonNode jsonNode = objectMapper.valueToTree(user);
		ProducerRecord<String, JsonNode> rec = new ProducerRecord<String, JsonNode>(topicName, jsonNode);
		producer.send(rec);
		producer.close();

	}

}
