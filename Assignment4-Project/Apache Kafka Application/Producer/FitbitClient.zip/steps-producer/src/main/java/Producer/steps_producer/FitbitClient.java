package Producer.steps_producer;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.TreeMap;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

//import com.owlike.genson.Genson;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadLocalRandom;

public class FitbitClient {
	static int requestCount = 0;
	static int responseCount = 0;
	static int counter = 0;
	static HashMap<Long, ArrayList<Long>> map;
	static TreeMap<Long, ArrayList<Long>> treeMap;
	static TreeMap<Long, Integer> requestsPerSecondMap;
	static BlockingQueue<Integer> bq = new LinkedBlockingQueue<Integer>();
	static BlockingQueue<Integer> bq1 = new LinkedBlockingQueue<Integer>();
	static BlockingQueue<Integer> bq2 = new LinkedBlockingQueue<Integer>();
//	static BlockingQueue<UserLatency> bq3 = new LinkedBlockingQueue<UserLatency>();
	static BlockingQueue<User> bq4 = new LinkedBlockingQueue<User>();
//	static ReqSent rq = new ReqSent(bq);
//	static ResReceived rs = new ResReceived(bq1);
//	static SuccessResponse suc = new SuccessResponse(bq2);
//	static AddToMap addMap = new AddToMap(bq3);
	static SendToKafka kafka = new SendToKafka(bq4);

	public static void main(String args[]) throws FileNotFoundException, IOException {
		int threadCount = new Integer(args[0]);
		String url = args[1];
		int dayNum = new Integer(args[2]);
		int userSize = new Integer(args[3]);
		int iterationCount = new Integer(args[4]);
		double[] phaseFactors = new double[] { 0.1, 0.5, 1.0, 0.25 };
		String[] phaseTypes = new String[] { "Warmup", "Load", "Peak", "Cooldown" };
		int[] phaseLength = new int[] { 3, 5, 11, 5 };
		int[][] phaseMaxMin = new int[][] { { 0, 2 }, { 3, 7 }, { 8, 18 }, { 19, 23 } };
		Client client = ClientBuilder.newClient();
		int initialCapacity = threadCount * iterationCount * 5 * 24;
		map = new HashMap<Long, ArrayList<Long>>();
		final WebTarget[] webTarget = {
				client.target("http://" + url + ":8080/FitbitServer-1.0-SNAPSHOT/resources/fitbit"),
				client.target("http://" + url + ":8080/FitbitServer-1.0-SNAPSHOT/resources/fitbit/current"),
				client.target("http://" + url + ":8080/FitbitServer-1.0-SNAPSHOT/resources/fitbit/single")
//				,client.target("http://" + url + ":8080/truncate")
		};
		System.out.println("Client: Thread Count: " + threadCount + ", Iteration Count: " + iterationCount);
		long clientStart = System.currentTimeMillis();
		System.out.println("Client starting time: " + clientStart + " milliseconds");
		for (int i = 0; i < phaseFactors.length; i++) {
//			String truncate = callTruncate(webTarget[3]);
			createPhase(threadCount, phaseTypes[i], phaseFactors[i], phaseLength[i], webTarget, phaseMaxMin[i],
					iterationCount, dayNum, userSize);
		}
		long endTime = System.currentTimeMillis();
		while (!bq4.isEmpty()) {
			kafka.run();
		}
		client.close();
		
		System.out.println("Client end time: " + endTime + " milliseconds");
		System.out.println("=========================================");
//		System.out.println("Total requests sent: " + requestCount);
//		System.out.println("Total response received: " + responseCount);
		double wall = (endTime - clientStart) / 1000f;
		System.out.printf("Total wall time: %.3f seconds\n", wall);
//		System.out.println("Total number of successful requests: " + counter);
//		double throughput = requestCount / wall;
//		System.out.println("Overall throughput across all phases: " + throughput + " seconds");
//		mapToSecondsBucket();
//		int pos95 = (int) (treeMap.size() * 0.95);
//		int pos99 = (int) (treeMap.size() * 0.99);
//		int count = 0;
//		float p95 = 0, p99 = 0;
//		for (Entry e : map.entrySet()) {
//			ArrayList<Long> l = (ArrayList<Long>) e.getValue();
//			if (count == pos95) {
//				p95 = getLatencyFromList(l);
//			}
//			if (count == pos99) {
//				p99 = getLatencyFromList(l);
//			}
//			count += 1;
//		}
//		System.out.printf("latency of 95th Percentile: %.3f seconds\n", p95);
//		System.out.printf("latency of 99th Percentile: %.3f seconds\n", p99);
//
//		File file1 = new File("./output1.txt");
//		BufferedWriter writer = new BufferedWriter(new FileWriter(file1));
//		for (Entry e : treeMap.entrySet()) {
//			writer.write(e.getKey() + "-" + e.getValue().toString() + "\n");
//		}
//		writer.close();
//		File file2 = new File("./output2.txt");
//		writer = new BufferedWriter(new FileWriter(file2));
//		for (Entry e : requestsPerSecondMap.entrySet()) {
//			writer.write(e.getKey() + "-" + e.getValue().toString() + "\n");
//		}
//		writer.close();

	}

	public static float getLatencyFromList(ArrayList<Long> list) {
		float result = 0f;
		if (list.size() == 1) {
			result = list.get(0) / 1000f;
			return result;
		}
		int sum = 0;
		for (long var : list) {
			sum += var;
		}
		result = (sum / list.size()) / 1000f;
		return result;
	}

	public static void createPhase(int threadCount, String phaseType, double phaseFactor, int phaseLength,
			WebTarget[] webTarget, int[] phaseMaxMin, int iterationCount, int day, int userSize) {
		int totalThreads = (int) (threadCount * phaseFactor);
		CountDownLatch latch = new CountDownLatch(totalThreads);
		iterationCount *= phaseLength;
		ExecutorService executor = Executors.newFixedThreadPool(totalThreads);
		long startTime = System.currentTimeMillis();
		for (int i = 0; i < totalThreads; i++) {
			executor.submit(new MyThreadClass(latch, webTarget, phaseMaxMin, iterationCount, day, userSize));
		}
		System.out.println(phaseType + " phase:All threads running...");
		try {
			latch.await();
		} catch (InterruptedException ex) {
			Logger.getLogger(FitbitClient.class.getName()).log(Level.SEVERE, null, ex);
		}
		executor.shutdown();
		long endTime = System.currentTimeMillis();
		System.out.printf(phaseType + " phase complete time: %.3f seconds\n", ((endTime - startTime) / 1000f));
		
	}

	public static String callTruncate(WebTarget target) {
		try {
			Response response = target.request(MediaType.TEXT_PLAIN).post(Entity.json(null));
			String res = response.readEntity(String.class);
			response.close();
			return res;
		} catch (Exception e) {
			e.printStackTrace();
			return "N";
		}

	}

	public static int callGetCurrent(WebTarget target) {
		try {
			bq.offer(1);
			Response response = target.request(MediaType.TEXT_PLAIN).get();
			int steps = response.readEntity(Integer.class);
			response.close();
			bq1.offer(1);
			return steps;
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}

	}

	public static int callGetSingle(WebTarget target) {
		try {
			bq.offer(1);
			Response response = target.request(MediaType.TEXT_PLAIN).get();
			int steps = response.readEntity(Integer.class);
			bq1.offer(1);
			return steps;
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}

	}

	public static int callPost(WebTarget target) {
		try {
			int result = -1;
			bq.offer(1);
			Response response = target.request(MediaType.TEXT_PLAIN).post(Entity.json(null));
			result = (int) response.readEntity(Integer.class);
			bq1.offer(1);
			return result;
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}

	}

	public static void mapToSecondsBucket() {
		treeMap = new TreeMap<Long, ArrayList<Long>>(map);
		requestsPerSecondMap = new TreeMap<Long, Integer>();
		long prev = 0, next = 1, toCompare = 0;
		for (Entry<Long, ArrayList<Long>> e : treeMap.entrySet()) {
			if (prev == 0) {
				requestsPerSecondMap.put(prev, ((ArrayList) e.getValue()).size());
				prev = next;
				toCompare = (long) e.getKey();
			} else {
				if ((long) e.getKey() - toCompare > 1000) {
					requestsPerSecondMap.put(next, ((ArrayList) e.getValue()).size());
					prev = next;
					next = next + 1;
					toCompare = (long) e.getKey();
				} else {
					int count = requestsPerSecondMap.get(next - 1) + ((ArrayList) e.getValue()).size();
					requestsPerSecondMap.put(next - 1, count);
				}

			}

		}
	}

	static class MyThreadClass implements Runnable {

		private final CountDownLatch stopLatch;
		private final WebTarget[] webTarget;
		private final int iterationCount;
		private final int day;
		private final int userSize;
		private final int[] maxMin;
		private final int[] user = new int[3];
		private final int[] time = new int[3];
		private final int[] step = new int[3];

		public MyThreadClass(CountDownLatch stopLatch, WebTarget[] webTarget, int[] maxMin, int iterationCount, int day,
				int userSize) {
			super();
			this.stopLatch = stopLatch;
			this.webTarget = webTarget;
			this.iterationCount = iterationCount;
			this.day = day;
			this.userSize = userSize;
			this.maxMin = maxMin;
		}

		public void run() {
			for (int i = 0; i < iterationCount; i++) {
				for (int j = 0; j < 3; j++) {
					user[j] = ThreadLocalRandom.current().nextInt(userSize) + 1;
					time[j] = getRandomTimeInRange();
					step[j] = ThreadLocalRandom.current().nextInt(5000) + 1;
					int day = ThreadLocalRandom.current().nextInt(30)+1;
					String record = user[j] + "/" + day + "/" + time[j] + "/" + step[j];
					try {
						Producer.send("usersteps", record);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				
			}
			stopLatch.countDown();
		}

		private int getRandomTimeInRange() {
			return ThreadLocalRandom.current().nextInt((maxMin[1] - maxMin[0]) + 1) + maxMin[0];
		}

		
	}


	static class SendToKafka implements Runnable {
		BlockingQueue<User> q;

		public SendToKafka(BlockingQueue queue) {
			this.q = queue;
		}

		public void run() {
			try {
				while (!q.isEmpty()) {
					User temp = (User) q.take();
					int userId = temp.getUserid();
					int day = temp.getDay();
					int hour = temp.getHour();
					int steps = temp.getSteps();
					String record = userId + "/" + day + "/" + hour + "/" + steps;
					Producer.send("usersteps", record);
				}
			} catch (InterruptedException ex) {
				Logger.getLogger(FitbitClient.class.getName()).log(Level.SEVERE, null, ex);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
