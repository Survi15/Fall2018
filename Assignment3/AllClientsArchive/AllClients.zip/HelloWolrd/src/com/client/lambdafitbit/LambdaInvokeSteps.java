package com.client.lambdafitbit;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.lambda.AWSLambda;
import com.amazonaws.services.lambda.AWSLambdaClientBuilder;
import com.amazonaws.services.lambda.model.InvokeRequest;
import com.amazonaws.services.lambda.model.InvokeResult;
import java.nio.ByteBuffer;

import javax.json.Json;
import javax.json.JsonReader;

import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.glassfish.jersey.apache.connector.ApacheClientProperties;
import org.glassfish.jersey.apache.connector.ApacheConnectorProvider;
import org.glassfish.jersey.client.ClientConfig;

import java.io.StringReader;

public class LambdaInvokeSteps {
	public static int postSteps(int id, int day, int hour, int steps) {
		return invokeGeneric("PostSteps", 
				String.format("{\"userID\":%d,\"day\":%d,\"timeInterval\":%d,\"stepCount\":%d}", id, day, hour, steps));
	}
	
	public static int getCount(int id, int day) {
		return invokeGeneric("GetCount", 
				String.format("{\"userID\":%d,\"day\":%d}", id, day));
	}
	
	public static int getCurrent(int id) {
		return invokeGeneric("GetCurrent", 
				String.format("{\"userID\":%d}", id));
	}

	private static int invokeGeneric(String functionName, String payLoad) {
		InvokeRequest invokeRequest = new InvokeRequest().withFunctionName(functionName).withPayload(payLoad);
		ClientConfiguration clientConfig = new ClientConfiguration();
		clientConfig.setMaxConnections(300);
		clientConfig.setMaxConsecutiveRetriesBeforeThrottling(3);
		AWSLambda awsLambda = AWSLambdaClientBuilder.standard().withClientConfiguration(clientConfig).withRegion(Regions.US_WEST_2).build();
	
		try {
			InvokeResult invokeResult = awsLambda.invoke(invokeRequest);
			ByteBuffer byteBuffer = invokeResult.getPayload();
			String rawJson = new String(byteBuffer.array(), "UTF-8");
			StringReader stringReader = new StringReader(rawJson);
			JsonReader jsonReader = Json.createReader(stringReader);
			int result = Integer.parseInt(jsonReader.readObject().getString("response"));
			return result;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}
}
