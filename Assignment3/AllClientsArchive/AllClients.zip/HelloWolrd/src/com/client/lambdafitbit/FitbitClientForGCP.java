package com.client.lambdafitbit;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.TreeMap;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.owlike.genson.Genson;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadLocalRandom;
public class FitbitClientForGCP {
	static int requestCount = 0;
	static int responseCount = 0;
	static int counter = 0;
	static HashMap<Long, ArrayList<Long>> map;
	static TreeMap<Long, ArrayList<Long>> treeMap;
	static TreeMap<Long, Integer> requestsPerSecondMap;
	static BlockingQueue<Integer> bq = new LinkedBlockingQueue<>();
	static BlockingQueue<Integer> bq1 = new LinkedBlockingQueue<>();
	static BlockingQueue<Integer> bq2 = new LinkedBlockingQueue<>();
	static BlockingQueue<User> bq3 = new LinkedBlockingQueue<>();
	static ReqSent rq = new ReqSent(bq);
	static ResReceived rs = new ResReceived(bq1);
	static SuccessResponse suc = new SuccessResponse(bq2);
	static AddToMap addMap = new AddToMap(bq3);
	public static void main(String args[]) throws FileNotFoundException, IOException {
		int threadCount = new Integer(args[0]);
		String url = args[1];
		int dayNum = new Integer(args[2]);
		int userSize = new Integer(args[3]);
		int iterationCount = new Integer(args[4]);
		double[] phaseFactors = new double[] { 0.1, 0.5, 1.0, 0.25 };
		String[] phaseTypes = new String[] { "Warmup", "Load", "Peak", "Cooldown" };
		int[] phaseLength = new int[] { 3, 5, 11, 5 };
		int[][] phaseMaxMin = new int[][] { { 0, 2 }, { 3, 7 }, { 8, 18 }, { 19, 23 } };
		Client client = ClientBuilder.newClient();
		int initialCapacity = threadCount * iterationCount * 5 * 24;
		map = new HashMap<>();
		final WebTarget[] webTarget = { client.target("http://" + url + ":8080/FitbitServer-1.0-SNAPSHOT/resources/fitbit"),
				client.target("http://" + url + ":8080/FitbitServer-1.0-SNAPSHOT/resources/fitbit/current"), 
				client.target("http://" + url + ":8080/FitbitServer-1.0-SNAPSHOT/resources/fitbit/single")
//				,client.target("http://" + url + ":8080/truncate")
				};
		System.out.println("Client: Thread Count: " + threadCount + ", Iteration Count: " + iterationCount);
		long clientStart = System.currentTimeMillis();
		System.out.println("Client starting time: " + clientStart + " milliseconds");
		for (int i = 0; i < phaseFactors.length; i++) {
//			String truncate = callTruncate(webTarget[3]);
			createPhase(threadCount, phaseTypes[i], phaseFactors[i], phaseLength[i], webTarget, phaseMaxMin[i],
					iterationCount, dayNum, userSize);
		}
		long endTime = System.currentTimeMillis();
		client.close();
		rq.run();
		rs.run();
		suc.run();
		while (!bq3.isEmpty()) {
			addMap.run();
		}
		System.out.println("Client end time: " + endTime + " milliseconds");
		System.out.println("=========================================");
		System.out.println("Total requests sent: " + requestCount);
		System.out.println("Total response received: " + responseCount);
		double wall = (endTime - clientStart) / 1000f;
		System.out.printf("Total wall time: %.3f seconds\n", wall);
		System.out.println("Total number of successful requests: " + counter);
		double throughput = requestCount / wall;
		System.out.println("Overall throughput across all phases: " + throughput + " seconds");
		mapToSecondsBucket();
		int pos95 = (int) (treeMap.size() * 0.95);
		int pos99 = (int) (treeMap.size() * 0.99);
		int count = 0;
		float p95 = 0, p99 = 0;
		for (Entry e : map.entrySet()) {
			ArrayList<Long> l = (ArrayList<Long>) e.getValue();
			if (count == pos95) {
				p95 = getLatencyFromList(l);
			}
			if (count == pos99) {
				p99 = getLatencyFromList(l);
			}
			count += 1;
		}
		System.out.printf("latency of 95th Percentile: %.3f seconds\n", p95);
		System.out.printf("latency of 99th Percentile: %.3f seconds\n", p99);

		File file1 = new File("./output1.txt");
		BufferedWriter writer = new BufferedWriter(new FileWriter(file1));
		for (Entry e : treeMap.entrySet()) {
			writer.write(e.getKey() + "-" + e.getValue().toString() + "\n");
		}
		writer.close();
		File file2 = new File("./output2.txt");
		writer = new BufferedWriter(new FileWriter(file2));
		for (Entry e : requestsPerSecondMap.entrySet()) {
			writer.write(e.getKey() + "-" + e.getValue().toString() + "\n");
		}
		writer.close();

	}

	public static float getLatencyFromList(ArrayList<Long> list) {
		float result = 0f;
		if (list.size() == 1) {
			result = list.get(0) / 1000f;
			return result;
		}
		int sum = 0;
		for (long var : list) {
			sum += var;
		}
		result = (sum / list.size()) / 1000f;
		return result;
	}

	public static void createPhase(int threadCount, String phaseType, double phaseFactor, int phaseLength,
			WebTarget[] webTarget, int[] phaseMaxMin, int iterationCount, int day, int userSize) {
		int totalThreads = (int) (threadCount * phaseFactor);
		CountDownLatch latch = new CountDownLatch(totalThreads);
		iterationCount *= phaseLength;
		ExecutorService executor = Executors.newFixedThreadPool(totalThreads);
		long startTime = System.currentTimeMillis();
		for (int i = 0; i < totalThreads; i++) {
			executor.submit(new MyThreadClass(latch, webTarget, phaseMaxMin, iterationCount, day, userSize));
		}
		System.out.println(phaseType + " phase:All threads running...");
		try {
			latch.await();
		} catch (InterruptedException ex) {
			Logger.getLogger(FitbitClient.class.getName()).log(Level.SEVERE, null, ex);
		}
		executor.shutdown();
		long endTime = System.currentTimeMillis();
		System.out.printf(phaseType + " phase complete time: %.3f seconds\n", ((endTime - startTime) / 1000f));

	}

	public static String callTruncate(WebTarget target) {
		try {
			Response response = target.request(MediaType.TEXT_PLAIN).post(Entity.json(null));
			String res = response.readEntity(String.class);
			response.close();
			return res;
		} catch (Exception e) {
			e.printStackTrace();
			return "N";
		}

	}

	public static int callGetCurrent(WebTarget target) {
		try {
			bq.offer(1);
			Response response = target.request(MediaType.TEXT_PLAIN).get();
			int steps = response.readEntity(Integer.class);
			response.close();
			bq1.offer(1);
			return steps;
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}

	}

	public static int callGetSingle(WebTarget target) {
		try {
			bq.offer(1);
			Response response = target.request(MediaType.TEXT_PLAIN).get();
			int steps = response.readEntity(Integer.class);
			bq1.offer(1);
			return steps;
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}

	}

	public static int callPost(WebTarget target) {
		try {
			int result = -1;
			bq.offer(1);
			Response response = target.request(MediaType.TEXT_PLAIN).post(Entity.json(null));
			result =(int)response.readEntity(Integer.class);
			bq1.offer(1);
			return result;
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}

	}

	public static void mapToSecondsBucket() {
		treeMap = new TreeMap<>(map);
		requestsPerSecondMap = new TreeMap<>();
		long prev = 0, next = 1, toCompare = 0;
		for (Entry<Long, ArrayList<Long>> e : treeMap.entrySet()) {
			if (prev == 0) {
				requestsPerSecondMap.put(prev, ((ArrayList) e.getValue()).size());
				prev = next;
				toCompare = (long) e.getKey();
			} else {
				if ((long) e.getKey() - toCompare > 1000) {
					requestsPerSecondMap.put(next, ((ArrayList) e.getValue()).size());
					prev = next;
					next = next + 1;
					toCompare = (long) e.getKey();
				} else {
					int count = requestsPerSecondMap.get(next - 1) + ((ArrayList) e.getValue()).size();
					requestsPerSecondMap.put(next - 1, count);
				}

			}

		}
	}

	static class MyThreadClass implements Runnable {

		private final CountDownLatch stopLatch;
		private final WebTarget[] webTarget;
		private final int iterationCount;
		private final int day;
		private final int userSize;
		private final int[] maxMin;
		private final int[] user = new int[3];
		private final int[] time = new int[3];
		private final int[] step = new int[3];

		public MyThreadClass(CountDownLatch stopLatch, WebTarget[] webTarget, int[] maxMin, int iterationCount, int day,
				int userSize) {
			super();
			this.stopLatch = stopLatch;
			this.webTarget = webTarget;
			this.iterationCount = iterationCount;
			this.day = day;
			this.userSize = userSize;
			this.maxMin = maxMin;
		}

		@Override
		public void run() {
			for (int i = 0; i < iterationCount; i++) {
				for (int j = 0; j < 3; j++) {
					user[j] = ThreadLocalRandom.current().nextInt(userSize) + 1;
					time[j] = getRandomTimeInRange();
					step[j] = ThreadLocalRandom.current().nextInt(5000) + 1;
				}
				long startTime = System.currentTimeMillis();
				if (checkPost(user[0], time[0], step[0])) {

					long latency = System.currentTimeMillis() - startTime;
					bq2.offer(1);
					bq3.offer(new User(startTime, latency));
				}
				startTime = System.currentTimeMillis();
				if (checkPost(user[1], time[1], step[1])) {
					long latency = System.currentTimeMillis() - startTime;
					bq2.offer(1);
					bq3.offer(new User(startTime, latency));
				}

				startTime = System.currentTimeMillis();
				int current = callGetCurrent(
						webTarget[1].path("{userID}").resolveTemplate("userID", String.valueOf(user[0])));
				if (current!=-1) {
					long latency = System.currentTimeMillis() - startTime;
					bq2.offer(1);
					bq3.offer(new User(startTime, latency));
				}
				startTime = System.currentTimeMillis();
				int daySteps = callGetSingle(
						webTarget[2].path("{userID}").resolveTemplate("userID", String.valueOf(user[1])).path("{day}")
								.resolveTemplate("day", String.valueOf(day)));
				if (daySteps!=-1) {
					long latency = System.currentTimeMillis() - startTime;
					bq2.offer(1);
					bq3.offer(new User(startTime, latency));
				}
				startTime = System.currentTimeMillis();
				if (checkPost(user[2], time[2], step[2])) {
					long latency = System.currentTimeMillis() - startTime;
					bq2.offer(1);
					bq3.offer(new User(startTime, latency));
				}
			}
			stopLatch.countDown();
		}

		private int getRandomTimeInRange() {
			return ThreadLocalRandom.current().nextInt((maxMin[1] - maxMin[0]) + 1) + maxMin[0];
		}

		private boolean checkPost(int user, int time, int step) {
			return callPost(webTarget[0].path("{userID}").resolveTemplate("userID", String.valueOf(user)).path("{day}")
					.resolveTemplate("day", String.valueOf(day)).path("{timeInterval}")
					.resolveTemplate("timeInterval", String.valueOf(time)).path("{stepCount}")
					.resolveTemplate("stepCount", String.valueOf(step)))!=-1;
		}
	}

	static class ReqSent implements Runnable {

		BlockingQueue<Integer> q;

		public ReqSent(BlockingQueue queue) {
			this.q = queue;
		}

		public void run() {
			try {
				while (!q.isEmpty()) {
					requestCount += (int) q.take();
				}
			} catch (InterruptedException ex) {
				Logger.getLogger(FitbitClient.class.getName()).log(Level.SEVERE, null, ex);
			}
		}
	}

	static class ResReceived implements Runnable {

		BlockingQueue<Integer> q;

		public ResReceived(BlockingQueue queue) {
			this.q = queue;
		}

		public void run() {
			try {
				while (!q.isEmpty()) {
					responseCount += (int) q.take();
				}
			} catch (InterruptedException ex) {
				Logger.getLogger(FitbitClient.class.getName()).log(Level.SEVERE, null, ex);
			}
		}
	}

	static class SuccessResponse implements Runnable {

		BlockingQueue<Integer> q;

		public SuccessResponse(BlockingQueue queue) {
			this.q = queue;
		}

		public void run() {
			try {
				while (!q.isEmpty()) {
					counter += (int) q.take();
				}
			} catch (InterruptedException ex) {
				Logger.getLogger(FitbitClient.class.getName()).log(Level.SEVERE, null, ex);
			}
		}
	}

	static class User {

		Long time;
		Long latency;

		public User(Long time, Long latency) {
			this.time = time;
			this.latency = latency;
		}

		public Long getTime() {
			return time;
		}

		public void setTime(Long time) {
			this.time = time;
		}

		public Long getLatency() {
			return latency;
		}

		public void setLatency(Long latency) {
			this.latency = latency;
		}

	}

	static class AddToMap implements Runnable {

		BlockingQueue<User> q;

		public AddToMap(BlockingQueue queue) {
			this.q = queue;
		}

		public void run() {
			try {
				while (!q.isEmpty()) {
					User temp = (User) q.take();
					Long time = temp.getTime();
					Long latency = temp.getLatency();

					if (map.containsKey(time)) {
						ArrayList l = map.get(time);
						l.add(latency);
						map.put(time, l);
						return;
					}
					ArrayList<Long> l = new ArrayList<>();
					l.add(latency);
					map.put(time, l);
				}
			} catch (InterruptedException ex) {
				Logger.getLogger(FitbitClient.class.getName()).log(Level.SEVERE, null, ex);
			}
		}
	}

}
